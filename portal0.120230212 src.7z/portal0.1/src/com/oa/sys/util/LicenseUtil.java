package com.oa.sys.util;

/**
 * Created by zf on 2023年2月11日.
 */
public class LicenseUtil {
	public static String getOSInfo() {
		return "Operating System=" + System.getProperty("os.name") + ", version=" + System.getProperty("os.version")
				+ ", platform=" + System.getProperty("os.arch");
	}

	public static String getCopyrightYear() {
		return "Copyright &copy; 2022-" + DateUtil.copyrightYear() + "  " + "Workbench";
	}

}
