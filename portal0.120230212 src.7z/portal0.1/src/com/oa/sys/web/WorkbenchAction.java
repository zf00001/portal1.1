/*
 * $Id$
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.oa.sys.web;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.oa.sys.util.ImageUtil;
import com.oa.sys.util.LicenseUtil;
import com.opensymphony.xwork2.ActionSupport;

/**
 * <code>DateAction</code>
 */
@Namespace("/oa/sys/workbench")
@Results({ @Result(name = "aboutUI", location = "about.jsp"), @Result(name = "imageSuccess", type = "stream", params = {
		"contentType", "image/jpeg", "inputName", "imageStream", "bufferSize", "2048" }) })
public class WorkbenchAction extends ActionSupport {
	public String image() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		// 文件类型
		response.setContentType("image/jpeg");
		// 设置缓存
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);

		ImageUtil imageUtil = new ImageUtil();
		BufferedImage image = imageUtil.getImage();

		request.getSession().setAttribute("text", imageUtil.getText());

		// 获取流发送给前台
		ServletOutputStream outputStream = response.getOutputStream();
		ImageIO.write(image, "JPEG", outputStream);

		return "imageSuccess";
	}

	public String getCopyrightYear() {
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");

		PrintWriter pw = null;
		try {
			pw = response.getWriter();
			pw.write(LicenseUtil.getCopyrightYear());
			pw.flush();
			pw.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

		return null;
	}

	public String aboutUI() throws Exception {
		return "aboutUI";
	}

	public String getOSInfo() {
		HttpServletRequest request = ServletActionContext.getRequest();

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");

		PrintWriter pw = null;
		try {
			pw = response.getWriter();
			pw.write(LicenseUtil.getOSInfo());
			pw.flush();
			pw.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

		return null;
	}

}
