package com.oa.sys.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysDepartmentService;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.util.DataUtil;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.PageUtil;
import com.oa.sys.util.UUIDUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by zf on 2023年2月2日.
 */
@Namespace("/oa/sys/department")
@Results({ @Result(name = "findAll", location = "list.jsp"), @Result(name = "addUI", location = "add.jsp"),
		@Result(name = "saveSuccess", type = "redirectAction", location = "department!findAll.do"),
		@Result(name = "editUI", location = "edit.jsp"),
		@Result(name = "updateSuccess", type = "redirectAction", location = "department!findAll.do"),
		@Result(name = "deleteSuccess", type = "redirectAction", location = "department!findAll.do")

})
public class DepartmentAction extends ActionSupport implements ModelDriven<OaSysDepartment> {
	private OaSysDepartment oaSysDepartment = new OaSysDepartment();

	@Override
	public OaSysDepartment getModel() {
		return oaSysDepartment;
	}

	private Integer currPage = 1;

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	@Autowired
	private OaSysDepartmentService oaSysDepartmentService;

	public OaSysDepartmentService getOaSysDepartmentService() {
		return oaSysDepartmentService;
	}

	public void setOaSysDepartmentService(OaSysDepartmentService oaSysDepartmentService) {
		this.oaSysDepartmentService = oaSysDepartmentService;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}

	public String findAll() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "findAll";
		} else {
			PageUtil<OaSysDepartment> pageBean = oaSysDepartmentService.findByPage(currPage);
			ActionContext.getContext().getValueStack().push(pageBean);
		}
		return "findAll";
	}

	public String addUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
		}
		return "addUI";
	}

	public String save() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "saveSuccess";
		} else {
			oaSysDepartment.setCreatedUser(user.getUid());
			oaSysDepartment.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysDepartment.setModifiedUser(user.getUid());
			oaSysDepartment.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysDepartment.setIsdel(DataUtil.adddata);

			String uuid = UUIDUtil.getUUID();
			oaSysDepartment.setDid(uuid);
			oaSysDepartmentService.save(oaSysDepartment);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.departmentdatatype);
			oaSysLog.setDataid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("部门添加 " + oaSysDepartment.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "saveSuccess";
	}

	public String editUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
			OaSysDepartment oaSysDepartmentFromdb = oaSysDepartmentService.findById(oaSysDepartment.getDid());
			ActionContext.getContext().getValueStack().push(oaSysDepartmentFromdb);
		}
		return "editUI";
	}

	public String update() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "updateSuccess";
		} else {
			OaSysDepartment oaSysDepartmentFromdb = oaSysDepartmentService.findById(oaSysDepartment.getDid());
			oaSysDepartmentFromdb.setNumber(oaSysDepartment.getNumber());
			oaSysDepartmentFromdb.setName(oaSysDepartment.getName());
			oaSysDepartmentFromdb.setRemarks(oaSysDepartment.getRemarks());

			oaSysDepartmentFromdb.setModifiedUser(user.getUid());
			oaSysDepartmentFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysDepartmentService.update(oaSysDepartmentFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.departmentdatatype);
			oaSysLog.setDataid(oaSysDepartment.getDid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("部门编辑 " + oaSysDepartmentFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "updateSuccess";
	}

	public String delete() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "deleteSuccess";
		} else {
			OaSysDepartment oaSysDepartmentFromdb = oaSysDepartmentService.findById(oaSysDepartment.getDid());
			oaSysDepartmentFromdb.setIsdel(DataUtil.deletedata);

			oaSysDepartmentFromdb.setModifiedUser(user.getUid());
			oaSysDepartmentFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysDepartmentService.update(oaSysDepartmentFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.departmentdatatype);
			oaSysLog.setDataid(oaSysDepartment.getDid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("部门删除 " + oaSysDepartmentFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "deleteSuccess";
	}

}
