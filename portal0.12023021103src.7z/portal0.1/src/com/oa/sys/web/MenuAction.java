package com.oa.sys.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysMenu;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.service.OaSysMenuService;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.PageBean;
import com.oa.sys.util.UUIDUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by zf on 2023年2月2日.
 */
@Namespace("/oa/sys/menu")
@Results({ @Result(name = "findAll", location = "list.jsp"), @Result(name = "addUI", location = "add.jsp"),
		@Result(name = "saveSuccess", type = "redirectAction", location = "menu!findAll.do"),
		@Result(name = "editUI", location = "edit.jsp"),
		@Result(name = "updateSuccess", type = "redirectAction", location = "menu!findAll.do"),
		@Result(name = "deleteSuccess", type = "redirectAction", location = "menu!findAll.do")

})
public class MenuAction extends ActionSupport implements ModelDriven<OaSysMenu> {
	private OaSysMenu oaSysMenu = new OaSysMenu();

	@Override
	public OaSysMenu getModel() {
		return oaSysMenu;
	}

	private Integer currPage = 1;

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	@Autowired
	private OaSysMenuService oaSysMenuService;

	public OaSysMenuService getOaSysMenuService() {
		return oaSysMenuService;
	}

	public void setOaSysMenuService(OaSysMenuService oaSysMenuService) {
		this.oaSysMenuService = oaSysMenuService;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}

	public String findAll() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "findAll";
		} else {
			PageBean<OaSysMenu> pageBean = oaSysMenuService.findByPage(currPage);
			ActionContext.getContext().getValueStack().push(pageBean);
		}
		return "findAll";
	}

	public String addUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
		}
		return "addUI";
	}

	public String save() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "saveSuccess";
		} else {
			oaSysMenu.setCreatedUser(user.getUid());
			oaSysMenu.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysMenu.setModifiedUser(user.getUid());
			oaSysMenu.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysMenu.setIsdel("0");

			String uuid = UUIDUtil.getUUID();
			oaSysMenu.setMid(uuid);
			oaSysMenuService.save(oaSysMenu);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("4");
			oaSysLog.setOpid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("菜单添加 " + oaSysMenu.toString());
			oaSysLogService.save(oaSysLog);

		}
		return "saveSuccess";
	}

	public String editUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
			OaSysMenu oaSysMenuFromdb = oaSysMenuService.findById(oaSysMenu.getMid());
			ActionContext.getContext().getValueStack().push(oaSysMenuFromdb);
		}
		return "editUI";
	}

	public String update() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");

		if (user == null) {
			this.addActionError("请重新登录");
			return "updateSuccess";
		} else {
			OaSysMenu oaSysMenuFromdb = oaSysMenuService.findById(oaSysMenu.getMid());
			oaSysMenuFromdb.setNumber(oaSysMenu.getNumber());
			oaSysMenuFromdb.setName(oaSysMenu.getName());
			oaSysMenuFromdb.setRemarks(oaSysMenu.getRemarks());
			oaSysMenuFromdb.setUrl(oaSysMenu.getUrl());
			oaSysMenuFromdb.setLevel(oaSysMenu.getLevel());
			oaSysMenuFromdb.setParentId(oaSysMenu.getParentId());

			oaSysMenuFromdb.setModifiedUser(user.getUid());
			oaSysMenuFromdb.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysMenuService.update(oaSysMenuFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("4");
			oaSysLog.setOpid(oaSysMenu.getMid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("菜单编辑 " + oaSysMenuFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "updateSuccess";
	}

	public String delete() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "deleteSuccess";
		} else {
			OaSysMenu oaSysMenuFromdb = oaSysMenuService.findById(oaSysMenu.getMid());
			oaSysMenuFromdb.setIsdel("1");

			oaSysMenuFromdb.setModifiedUser(user.getUid());
			oaSysMenuFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysMenuService.update(oaSysMenuFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("4");
			oaSysLog.setOpid(oaSysMenu.getMid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("菜单删除 " + oaSysMenuFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "deleteSuccess";
	}

}
