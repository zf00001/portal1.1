package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_menu")
public class OaSysMenu {
	@Id
	@GenericGenerator(name = "generator", strategy = "assigned")
	@GeneratedValue(generator = "generator")
	@Column(name = "mid", unique = true, nullable = false, length = 32)
	private String mid;
	@Column(name = "number", length = 32)
	private String number;
	@Column(name = "name", length = 32)
	private String name;

	@Column(name = "isdel", length = 1)
	private String isdel;
	@Column(name = "createdUser", length = 32)
	private String createdUser;
	@Column(name = "createdTime", length = 32)
	private String createdTime;
	@Column(name = "modifiedUser", length = 32)
	private String modifiedUser;
	@Column(name = "modifiedTime", length = 32)
	private String modifiedTime;

	@Column(name = "remarks", length = 100)
	private String remarks;
	@Column(name = "url", length = 200)
	private String url;
	@Column(name = "level", length = 1)
	private String level;
	@Column(name = "parentId", length = 32)
	private String parentId;

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	@Override
	public String toString() {
		return "OaSysMenu [mid=" + mid + ", number=" + number + ", name=" + name + ", isdel=" + isdel + ", createdUser="
				+ createdUser + ", createdTime=" + createdTime + ", modifiedUser=" + modifiedUser + ", modifiedTime="
				+ modifiedTime + ", url=" + url + ", level=" + level + ", parentId=" + parentId + "]";
	}

}