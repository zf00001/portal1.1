package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_user")
public class OaSysUser {
	@Id
	@GenericGenerator(name = "generator", strategy = "uuid.hex")
	@GeneratedValue(generator = "generator")
	@Column(name = "uid", unique = true, nullable = false, length = 32)
	private String uid;
	@Column(name = "number", length = 32)
	private String number;
	@Column(name = "name", length = 32)
	private String name;

	@Column(name = "isdel", length = 1)
	private String isdel;
	@Column(name = "issys", length = 1)
	private String issys;
	@Column(name = "createdUser", length = 32)
	private String createdUser;
	@Column(name = "createdTime", length = 32)
	private String createdTime;
	@Column(name = "modifiedUser", length = 32)
	private String modifiedUser;
	@Column(name = "modifiedTime", length = 32)
	private String modifiedTime;

	@Column(name = "username", length = 32)
	private String username;
	@Column(name = "password", length = 32)
	private String password;

	@Column(name = "email", length = 32)
	private String email;
	@Column(name = "phone", length = 32)
	private String phone;
	@Column(name = "birthday", length = 32)
	private String birthday;
	@Column(name = "gender", length = 1)
	private String gender;

	@ManyToOne
	@JoinColumn(name = "did")
	private OaSysDepartment oaSysDepartment;

	@OneToOne
	@JoinColumn(name = "rid")
	private OaSysRole oaSysRole;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public String getIssys() {
		return issys;
	}

	public void setIssys(String issys) {
		this.issys = issys;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public OaSysDepartment getOaSysDepartment() {
		return oaSysDepartment;
	}

	public void setOaSysDepartment(OaSysDepartment oaSysDepartment) {
		this.oaSysDepartment = oaSysDepartment;
	}

	public OaSysRole getOaSysRole() {
		return oaSysRole;
	}

	public void setOaSysRole(OaSysRole oaSysRole) {
		this.oaSysRole = oaSysRole;
	}

	@Override
	public String toString() {
		return "OaSysUser [uid=" + uid + ", number=" + number + ", name=" + name + ", isdel=" + isdel + ", issys="
				+ issys + ", createdUser=" + createdUser + ", createdTime=" + createdTime + ", modifiedUser="
				+ modifiedUser + ", modifiedTime=" + modifiedTime + ", username=" + username + ", password=" + password
				+ ", email=" + email + ", phone=" + phone + ", birthday=" + birthday + ", gender=" + gender
				+ ", oaSysDepartment=" + oaSysDepartment.getDid() + ", oaSysRole=" + oaSysRole.getRid() + "]";
	}
	
}
