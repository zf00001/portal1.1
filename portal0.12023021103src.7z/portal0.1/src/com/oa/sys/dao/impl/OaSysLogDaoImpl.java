package com.oa.sys.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.oa.sys.dao.OaSysLogDao;
import com.oa.sys.model.OaSysLog;

/**
 * Created by zf on 2023年2月2日.
 */
@Repository
public class OaSysLogDaoImpl extends HibernateDaoSupport implements OaSysLogDao {

	@Override
	public int findCount(String optype, String opid) {
		String hql = "select count(*) from OaSysLog where optype='" + optype + "' and opid='" + opid + "' ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return Integer.parseInt(list.get(0).toString());
		} else {
			return 0;
		}
	}

	@Override
	public List<OaSysLog> findByPage(int begin, int pageSize, String optype, String opid) {
		DetachedCriteria criteria = DetachedCriteria.forClass(OaSysLog.class);
		criteria.add(Restrictions.eq("optype", optype));
		criteria.add(Restrictions.eq("opid", opid));
		criteria.addOrder(Order.desc("modifiedTime"));

		List<OaSysLog> list = (List<OaSysLog>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		return list;
	}

	@Override
	public void save(OaSysLog oaSysLog) {
		this.getHibernateTemplate().save(oaSysLog);

	}

	@Override
	public OaSysLog findById(String lid) {
		OaSysLog oaSysLog = this.getHibernateTemplate().get(OaSysLog.class, lid);
		return oaSysLog;
	}

}
