package com.oa.sys.dao;

import java.util.List;

import com.oa.sys.model.OaSysUser;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysUserDao {
	int findCount();

	List<OaSysUser> findByPage(int begin, int pageSize);

	void save(OaSysUser oaSysUser);

	OaSysUser findById(String uid);

	void update(OaSysUser oaSysUser);

	OaSysUser findByUsernameAndPassword(String username, String password);

	OaSysUser findByUsername(String username);

	OaSysUser findByUsernameForUpdate(String uid,String username);
}
