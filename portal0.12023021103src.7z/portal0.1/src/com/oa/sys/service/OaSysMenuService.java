package com.oa.sys.service;

import com.oa.sys.model.OaSysMenu;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.util.PageBean;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysMenuService {

	PageBean<OaSysMenu> findByPage(Integer currPage);

	void save(OaSysMenu oaSysMenu);

	OaSysMenu findById(String mid);

	void update(OaSysMenu oaSysMenu);

}
