package com.oa.sys.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oa.sys.dao.OaSysUserDao;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysUserService;
import com.oa.sys.util.PageBean;

/**
 * Created by zf on 2023年2月2日.
 */
@Service
public class OaSysUserServiceImpl implements OaSysUserService {
	@Autowired
	private OaSysUserDao oaSysUserDao;

	public OaSysUserDao getOaSysUserDao() {
		return oaSysUserDao;
	}

	public void setOaSysUserDao(OaSysUserDao oaSysUserDao) {
		this.oaSysUserDao = oaSysUserDao;
	}

	@Override
	public PageBean<OaSysUser> findByPage(Integer currPage) {
		PageBean<OaSysUser> pageBean = new PageBean<OaSysUser>();
		// 设置当前页数
		pageBean.setCurrPage(currPage);
		// 设置每页显示记录数
		int pageSize = 5;
		pageBean.setPageSize(pageSize);
		// 设置总记录数
		int totalCount = oaSysUserDao.findCount();
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		double tc = totalCount;
		Double num = Math.ceil(tc / pageSize);
		pageBean.setTotalPage(num.intValue());
		// 设置每页显示的数据
		int begin = (currPage - 1) * pageSize;
		List<OaSysUser> list = oaSysUserDao.findByPage(begin, pageSize);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(OaSysUser oaSysUser) {
		oaSysUserDao.save(oaSysUser);
	}

	@Override
	public OaSysUser findById(String uid) {
		return oaSysUserDao.findById(uid);
	}

	@Override
	public void update(OaSysUser oaSysUser) {
		oaSysUserDao.update(oaSysUser);
	}

	@Override
	public OaSysUser findByUsernameAndPassword(String username, String password) {
		return oaSysUserDao.findByUsernameAndPassword(username, password);
	}

	@Override
	public OaSysUser findByUsername(String username) {
		return oaSysUserDao.findByUsername(username);
	}
	
	@Override
	public OaSysUser findByUsernameForUpdate(String uid,String username) {
		return oaSysUserDao.findByUsernameForUpdate(uid,username);
	}
	

	private static Map<String, String> onlineOaSysUser = new HashMap<String, String>();

	@Override
	public void saveOnlineOaSysUser(String uid, String sessionid) {
		onlineOaSysUser.put(uid, sessionid);
	}

	@Override
	public void deleteOnlineOaSysUser(String uid) {
		onlineOaSysUser.remove(uid);
	}

}
