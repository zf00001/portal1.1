package com.oa.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oa.sys.dao.OaSysDepartmentDao;
import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.service.OaSysDepartmentService;
import com.oa.sys.util.PageBean;

/**
 * Created by zf on 2023年2月2日.
 */
@Service
public class OaSysDepartmentServiceImpl implements OaSysDepartmentService {
	@Autowired
	private OaSysDepartmentDao oaSysDepartmentDao;

	public OaSysDepartmentDao getOaSysDepartmentDao() {
		return oaSysDepartmentDao;
	}

	public void setOaSysDepartmentDao(OaSysDepartmentDao oaSysDepartmentDao) {
		this.oaSysDepartmentDao = oaSysDepartmentDao;
	}

	@Override
	public PageBean<OaSysDepartment> findByPage(Integer currPage) {
		PageBean<OaSysDepartment> pageBean = new PageBean<OaSysDepartment>();
		// 设置当前页数
		pageBean.setCurrPage(currPage);
		// 设置每页显示记录数
		int pageSize = 5;
		pageBean.setPageSize(pageSize);
		// 设置总记录数
		int totalCount = oaSysDepartmentDao.findCount();
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		double tc = totalCount;
		Double num = Math.ceil(tc / pageSize);
		pageBean.setTotalPage(num.intValue());
		// 设置每页显示的数据
		int begin = (currPage - 1) * pageSize;
		List<OaSysDepartment> list = oaSysDepartmentDao.findByPage(begin, pageSize);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(OaSysDepartment oaSysDepartment) {
		oaSysDepartmentDao.save(oaSysDepartment);
	}

	@Override
	public OaSysDepartment findById(String did) {
		return oaSysDepartmentDao.findById(did);
	}

	@Override
	public void update(OaSysDepartment oaSysDepartment) {
		oaSysDepartmentDao.update(oaSysDepartment);
	}

	@Override
	public List<OaSysDepartment> findAll() {
		return oaSysDepartmentDao.findAll();
	}
}
