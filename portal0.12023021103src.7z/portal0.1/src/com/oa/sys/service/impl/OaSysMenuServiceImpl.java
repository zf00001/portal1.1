package com.oa.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oa.sys.dao.OaSysMenuDao;
import com.oa.sys.model.OaSysMenu;
import com.oa.sys.service.OaSysMenuService;
import com.oa.sys.util.PageBean;

/**
 * Created by zf on 2023年2月2日.
 */
@Service
public class OaSysMenuServiceImpl implements OaSysMenuService {
	@Autowired
	private OaSysMenuDao oaSysMenuDao;

	public OaSysMenuDao getOaSysMenuDao() {
		return oaSysMenuDao;
	}

	public void setOaSysMenuDao(OaSysMenuDao oaSysMenuDao) {
		this.oaSysMenuDao = oaSysMenuDao;
	}

	@Override
	public PageBean<OaSysMenu> findByPage(Integer currPage) {
		PageBean<OaSysMenu> pageBean = new PageBean<OaSysMenu>();
		// 设置当前页数
		pageBean.setCurrPage(currPage);
		// 设置每页显示记录数
		int pageSize = 5;
		pageBean.setPageSize(pageSize);
		// 设置总记录数
		int totalCount = oaSysMenuDao.findCount();
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		double tc = totalCount;
		Double num = Math.ceil(tc / pageSize);
		pageBean.setTotalPage(num.intValue());
		// 设置每页显示的数据
		int begin = (currPage - 1) * pageSize;
		List<OaSysMenu> list = oaSysMenuDao.findByPage(begin, pageSize);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(OaSysMenu oaSysMenu) {
		oaSysMenuDao.save(oaSysMenu);
	}

	@Override
	public OaSysMenu findById(String mid) {
		return oaSysMenuDao.findById(mid);
	}

	@Override
	public void update(OaSysMenu oaSysMenu) {
		oaSysMenuDao.update(oaSysMenu);
	}

}
