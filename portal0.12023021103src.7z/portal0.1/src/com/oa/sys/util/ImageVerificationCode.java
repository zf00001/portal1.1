package com.oa.sys.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

public class ImageVerificationCode {
	// 随机数
	private Random random = new Random();
	private String text;

	public ImageVerificationCode() {
		StringBuilder codeStr = new StringBuilder();
		// 要随机的字符串
		String codes = "123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		for (int i = 0; i < 5; i++) {
			// 获取随机出的字符
			int index = random.nextInt(codes.length() - 1);
			String tempNum = "" + codes.charAt(index);
			// 拼成字符串
			codeStr.append(tempNum);
		}
		text = "" + codeStr;
	}

	public String getText() {
		return text;
	}

	public BufferedImage getImage() {
		// 画板
		BufferedImage image = new BufferedImage(100, 40, BufferedImage.TYPE_INT_RGB);
		// 画笔
		Graphics g = image.getGraphics();
		// 字体
		Font font = new Font("微软雅黑", Font.BOLD, 25);
		// 设置字体
		g.setFont(font);

		// 设置背景色随机
		g.setColor(new Color(255, 255, random.nextInt(245) + 10));
		g.fillRect(0, 0, 100, 40);

		for (int i = 0; i < text.length(); i++) {
			String tempNum = "" + text.charAt(i);
			// 设置颜色
			g.setColor(new Color(random.nextInt(225), random.nextInt(225), random.nextInt(225)));
			// 字母写入图片
			g.drawString(tempNum, 18 * i + 5, 25);
		}
		return image;
	}

}