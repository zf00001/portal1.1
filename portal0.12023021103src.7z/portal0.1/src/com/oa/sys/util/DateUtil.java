package com.oa.sys.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by zf on 2023年2月8日.
 */
public class DateUtil {

	/* 获取当前时间 */
	public static String currentTimeMillis() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(System.currentTimeMillis());
	}

	public static String copyrightYear() {
		Calendar ca = Calendar.getInstance();
		ca.setTime(new Date());
		ca.add(Calendar.YEAR, +10);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		return sdf.format(ca.getTime());
	}

	public static String getOSInfo() {
		return "Operating System=" + System.getProperty("os.name") + ", version=" + System.getProperty("os.version")
				+ ", platform=" + System.getProperty("os.arch");
	}

	public static void main(String[] args) {
	}

}
