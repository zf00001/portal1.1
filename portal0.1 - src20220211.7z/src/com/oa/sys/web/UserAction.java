package com.oa.sys.web;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysDepartmentService;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.service.OaSysRoleService;
import com.oa.sys.service.OaSysUserService;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.ImageVerificationCode;
import com.oa.sys.util.MD5Util;
import com.oa.sys.util.PageBean;
import com.oa.sys.util.UUIDUtil;
import com.oa.sys.util.ValidateBean;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by zf on 2023年2月2日.
 */
@Namespace("/oa/sys/user")
@Results({ @Result(name = "findAll", location = "list.jsp"), @Result(name = "addUI", location = "add.jsp"),
		@Result(name = "saveSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "editUI", location = "edit.jsp"),
		@Result(name = "updateSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "deleteSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "loginUI", location = "login.jsp"), @Result(name = "loginSuccess", location = "welcome.jsp"),
		@Result(name = "logoutSuccess", location = "welcome.jsp"), @Result(name = "registUI", location = "regist.jsp"),
		@Result(name = "registSuccess", location = "welcome.jsp"),
		@Result(name = "imageSuccess", type = "stream", params = { "contentType", "image/jpeg", "inputName",
				"imageStream", "bufferSize", "2048" }),
		@Result(name = "exportExcelSuccess", type = "stream", params = { "contentType",
				"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", "contentDisposition",
				"attachment;filename=\"${downloadFileName}\"", "bufferSize", "1024" }) })
public class UserAction extends ActionSupport implements ModelDriven<OaSysUser> {
	private OaSysUser oaSysUser = new OaSysUser();

	@Override
	public OaSysUser getModel() {
		return oaSysUser;
	}

	private Integer currPage = 1;

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	@Autowired
	private OaSysUserService oaSysUserService;

	public OaSysUserService getOaSysUserService() {
		return oaSysUserService;
	}

	public void setOaSysUserService(OaSysUserService oaSysUserService) {
		this.oaSysUserService = oaSysUserService;
	}

	@Autowired
	private OaSysDepartmentService oaSysDepartmentService;

	public OaSysDepartmentService getOaSysDepartmentService() {
		return oaSysDepartmentService;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}

	public void setOaSysDepartmentService(OaSysDepartmentService oaSysDepartmentService) {
		this.oaSysDepartmentService = oaSysDepartmentService;
	}

	@Autowired
	private OaSysRoleService oaSysRoleService;

	public OaSysRoleService getOaSysRoleService() {
		return oaSysRoleService;
	}

	public void setOaSysRoleService(OaSysRoleService oaSysRoleService) {
		this.oaSysRoleService = oaSysRoleService;
	}

	public String findAll() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "findAll";
		} else {
			PageBean<OaSysUser> pageBean = oaSysUserService.findByPage(currPage);
			ActionContext.getContext().getValueStack().push(pageBean);
		}
		return "findAll";
	}

	public String addUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			ActionContext.getContext().getValueStack().set("departmentlist", new ArrayList<OaSysDepartment>());
			ActionContext.getContext().getValueStack().set("rolelist", new ArrayList<OaSysRole>());
			return "addUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
		}
		return "addUI";
	}

	public String save() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateBean validateBean = new ValidateBean();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "addUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsername(username);
		if (oaSysUserFromdb != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "addUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "saveSuccess";
		} else {

			oaSysUser.setCreatedUser(user.getUid());
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(user.getUid());
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys("0");
			oaSysUser.setIsdel("0");

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			String uuid = UUIDUtil.getUUID();
			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户添加 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "saveSuccess";
	}

	public String editUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			ActionContext.getContext().getValueStack().set("departmentlist", new ArrayList<OaSysDepartment>());
			ActionContext.getContext().getValueStack().set("rolelist", new ArrayList<OaSysRole>());
			return "editUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);

			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			oaSysUserFromdb.setPassword("");
			ActionContext.getContext().getValueStack().push(oaSysUserFromdb);
		}
		return "editUI";
	}

	public String update() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateBean validateBean = new ValidateBean();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "editUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdbForUpdate = oaSysUserService.findByUsernameForUpdate(oaSysUser.getUid(), username);
		if (oaSysUserFromdbForUpdate != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "editUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "updateSuccess";
		} else {
			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			// 修改基本信息
			oaSysUserFromdb.setNumber(oaSysUser.getNumber());
			oaSysUserFromdb.setName(oaSysUser.getName());
			oaSysUserFromdb.setUsername(oaSysUser.getUsername());
			oaSysUserFromdb.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));
			oaSysUserFromdb.setEmail(oaSysUser.getEmail());
			oaSysUserFromdb.setPhone(oaSysUser.getPhone());
			oaSysUserFromdb.setBirthday(oaSysUser.getBirthday());
			oaSysUserFromdb.setGender(oaSysUser.getGender());
			oaSysUserFromdb.setOaSysDepartment(oaSysUser.getOaSysDepartment());
			oaSysUserFromdb.setOaSysRole(oaSysUser.getOaSysRole());

			oaSysUserFromdb.setModifiedUser(user.getUid());
			oaSysUserFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysUserService.update(oaSysUserFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid(oaSysUser.getUid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户编辑 " + oaSysUserFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "updateSuccess";
	}

	public String delete() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "deleteSuccess";
		} else {
			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			oaSysUserFromdb.setIsdel("1");

			oaSysUserFromdb.setModifiedUser(user.getUid());
			oaSysUserFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysUserService.update(oaSysUserFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid(oaSysUser.getUid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户删除 " + oaSysUserFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "deleteSuccess";
	}

	public String loginUI() {
		return "loginUI";
	}

	private String imageVerificationCode;

	public String getImageVerificationCode() {
		return imageVerificationCode;
	}

	public void setImageVerificationCode(String imageVerificationCode) {
		this.imageVerificationCode = imageVerificationCode;
	}

	public String login() {
		HttpServletRequest request = ServletActionContext.getRequest();

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		// 获取用户填写的登录密码
		String password = request.getParameter("password");

		String textC = request.getParameter("imageVerificationCode");

		HttpSession session = request.getSession();
		String textS = (String) session.getAttribute("text");

		if (textS != null && textC != null && textS.toLowerCase().equals(textC.toLowerCase())) {

		} else {
			this.addFieldError("imageVerificationCode", "验证码不正确");
			return "loginUI";
		}

		ValidateBean validateBean = new ValidateBean();
		if (validateBean.validateLoin(oaSysUser) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			return "loginUI";
		}

		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsernameAndPassword(username,
				MD5Util.encrypt1ToMD5(password));

		if (oaSysUserFromdb == null) {
			this.addActionError("帐号或者密码错误");
			return "loginUI";
		} else {
			// 登录成功后，就将用户存储到session中

			OaSysUser onlineOaSysUser = new OaSysUser();
			onlineOaSysUser.setUid(oaSysUserFromdb.getUid());
			onlineOaSysUser.setName(oaSysUserFromdb.getName());
			onlineOaSysUser.setUsername(username);
			onlineOaSysUser.setPassword(password);

			session.setAttribute("user", onlineOaSysUser);
			oaSysUserService.saveOnlineOaSysUser("" + onlineOaSysUser.getUid(), "" + session.getId());

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid("");
			oaSysLog.setModifiedUser(oaSysUserFromdb.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户登录 ");
			oaSysLogService.save(oaSysLog);

			return "loginSuccess";
		}
	}

	public String logout() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();

		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user != null) {
			// 移除存储在session中的user对象，实现注销功能
			session.removeAttribute("user");
			oaSysUserService.deleteOnlineOaSysUser("" + user.getUid());

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid("");
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("退出登陆 ");
			oaSysLogService.save(oaSysLog);
		}
		// 销毁session
		session.invalidate();

		return "logoutSuccess";
	}

	public String registUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);

			return "registUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
		}
		return "registUI";
	}

	private String confirmPwd;

	public String getConfirmPwd() {
		return confirmPwd;
	}

	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}

	public String regist() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateBean validateBean = new ValidateBean();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "registUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsername(username);
		if (oaSysUserFromdb != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "registUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			String uuid = UUIDUtil.getUUID();

			oaSysUser.setCreatedUser(uuid);
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(uuid);
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys("0");
			oaSysUser.setIsdel("0");

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid(uuid);
			oaSysLog.setModifiedUser(uuid);
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户注册 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);

			this.addActionMessage("注册成功");
			return "registSuccess";
		} else {

			oaSysUser.setCreatedUser(user.getUid());
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(user.getUid());
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys("0");
			oaSysUser.setIsdel("0");

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			String uuid = UUIDUtil.getUUID();
			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setOptype("3");
			oaSysLog.setOpid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户注册 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);

			this.addActionMessage("注册成功");
		}
		return "registSuccess";
	}

	public String image() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		// 文件类型
		response.setContentType("image/jpeg");
		// 设置缓存
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);

		ImageVerificationCode ivc = new ImageVerificationCode();
		BufferedImage image = ivc.getImage();

		request.getSession().setAttribute("text", ivc.getText());

		// 获取流发送给前台
		ServletOutputStream outputStream = response.getOutputStream();
		ImageIO.write(image, "JPEG", outputStream);

		return "imageSuccess";
	}

	public String exportExcel() {
		HttpServletResponse response = ServletActionContext.getResponse();

		response.setHeader("Content-Disposition", "attachment;filename=Excel1A.xls");

		// 在内存中创建一个Excel文件
		XSSFWorkbook workbook = new XSSFWorkbook();
		// 创建工作表，指定工作表名称
		XSSFSheet sheet = workbook.createSheet("SheetA");

		// 创建行，0表示第一行
		XSSFRow row = sheet.createRow(0);
		// 创建单元格，0表示第一个单元格
		row.createCell(0).setCellValue("编号");
		row.createCell(1).setCellValue("姓名");
		row.createCell(2).setCellValue("年龄");

		XSSFRow row1 = sheet.createRow(1);
		row1.createCell(0).setCellValue("1");
		row1.createCell(1).setCellValue("张三");
		row1.createCell(2).setCellValue("10");

		try {
			// 获取流发送给前台
			ServletOutputStream outputStream = response.getOutputStream();
			try {
				workbook.write(outputStream);
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return "exportExcelSuccess";
	}
}
