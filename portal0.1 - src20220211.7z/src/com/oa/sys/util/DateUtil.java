package com.oa.sys.util;

import java.text.SimpleDateFormat;

/**
 * Created by zf on 2023年2月8日.
 */
public class DateUtil {

	/* 获取当前时间 */
	public static String currentTimeMillis() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(System.currentTimeMillis());
	}

	public static void main(String[] args) {
	}

}
