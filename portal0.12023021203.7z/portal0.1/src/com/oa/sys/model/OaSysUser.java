package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_user")
public class OaSysUser {
	@Id
	@GenericGenerator(name = "generator", strategy = "uuid.hex")
	@GeneratedValue(generator = "generator")
	@Column(name = "uid", unique = true, nullable = false, length = 32)
	private String uid;
	@Column(name = "number", length = 32)
	private String number;
	@Column(name = "name", length = 32)
	private String name;

	@Column(name = "isdel", length = 1)
	private String isdel;
	@Column(name = "createdUser", length = 32)
	private String createdUser;
	@Column(name = "createdUserName", length = 32)
	private String createdUserName;
	@Column(name = "createdTime", length = 32)
	private String createdTime;
	@Column(name = "modifiedUser", length = 32)
	private String modifiedUser;
	@Column(name = "modifiedUserName", length = 32)
	private String modifiedUserName;
	@Column(name = "modifiedTime", length = 32)
	private String modifiedTime;
	@Column(name = "states", length = 1)
	private String states;

	@Column(name = "issys", length = 1)
	private String issys;
	@Column(name = "username", length = 32)
	private String username;
	@Column(name = "password", length = 32)
	private String password;

	@Column(name = "email", length = 32)
	private String email;
	@Column(name = "phone", length = 32)
	private String phone;
	@Column(name = "birthday", length = 32)
	private String birthday;
	@Column(name = "gender", length = 1)
	private String gender;

	@Column(name = "did", length = 32)
	private String did;
	@Column(name = "dname", length = 32)
	private String dname;
	@Column(name = "rid", length = 32)
	private String rid;
	@Column(name = "rname", length = 32)
	private String rname;
	@Column(name = "license", length = 32)
	private String license;

	public String getLicense() {
		return license;
	}

	public void setLicense(String license) {
		this.license = license;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedUserName() {
		return modifiedUserName;
	}

	public void setModifiedUserName(String modifiedUserName) {
		this.modifiedUserName = modifiedUserName;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getStates() {
		return states;
	}

	public void setStates(String states) {
		this.states = states;
	}

	public String getIssys() {
		return issys;
	}

	public void setIssys(String issys) {
		this.issys = issys;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getRid() {
		return rid;
	}

	public void setRid(String rid) {
		this.rid = rid;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	@Override
	public String toString() {
		return "OaSysUser [uid=" + uid + ", number=" + number + ", name=" + name + "]";
	}

}
