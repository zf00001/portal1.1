package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_log")
public class OaSysLog {
	@Id
	@GenericGenerator(name = "generator", strategy = "uuid.hex")
	@GeneratedValue(generator = "generator")
	@Column(name = "lid", unique = true, nullable = false, length = 32)
	private String lid;

	@Column(name = "modifiedUser", length = 32)
	private String modifiedUser;
	@Column(name = "modifiedUserName", length = 32)
	private String modifiedUserName;
	@Column(name = "modifiedTime", length = 32)
	private String modifiedTime;

	@Column(name = "datatype", length = 32)
	private String datatype;
	@Column(name = "dataid", length = 32)
	private String dataid;
	@Column(name = "remarks", length = 500)
	private String remarks;

	public String getLid() {
		return lid;
	}

	public void setLid(String lid) {
		this.lid = lid;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedUserName() {
		return modifiedUserName;
	}

	public void setModifiedUserName(String modifiedUserName) {
		this.modifiedUserName = modifiedUserName;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getDataid() {
		return dataid;
	}

	public void setDataid(String dataid) {
		this.dataid = dataid;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "OaSysLog [lid=" + lid + ", datatype=" + datatype + ", dataid=" + dataid + "]";
	}

}
