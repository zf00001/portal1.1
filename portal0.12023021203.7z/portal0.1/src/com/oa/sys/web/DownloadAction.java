package com.oa.sys.web;

import java.io.InputStream;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;

import com.opensymphony.xwork2.ActionSupport;

@Namespace("/oa/sys/download")
public class DownloadAction extends ActionSupport {

//	 <result name="success" type="stream">
//     <param name="contentType">text/plain</param>
//     <param name="contentDisposition">attachment;fileName="${fileName}"</param>
//     <param name="inputName">downloadFile</param>
//     <param name="bufferSize">1024</param>
// </result>

	private int number;

	private String fileName;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	// 返回一个输入流，作为一个客户端来说是一个输入流，但对于服务器端是一个 输出流
	public InputStream getDownloadFile() throws Exception {
		if (1 == number) {
			this.fileName = "Dream.jpg";
			// 获取资源路径
			return ServletActionContext.getServletContext().getResourceAsStream("upload/Dream.jpg");
		}

		else if (2 == number) {
			this.fileName = "jd2chm源码生成chm格式文档.rar";
			// 解解乱码
			this.fileName = new String(this.fileName.getBytes("GBK"), "ISO-8859-1");
			return ServletActionContext.getServletContext().getResourceAsStream("upload/jd2chm源码生成chm格式文档.rar");
		} else
			return null;
	}

	@Override
	public String execute() throws Exception {

		return SUCCESS;
	}

}