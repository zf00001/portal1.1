/*
 * $Id$
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.oa.sys.web;

import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.opensymphony.xwork2.ActionSupport;

@Namespace("/oa/sys/excel")
@Results({ @Result(name = "exportExcelSuccess", type = "stream", params = { "contentType",
		"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", "contentDisposition",
		"attachment;filename=\"${downloadFileName}\"", "bufferSize", "1024" }) })
public class ExcelAction extends ActionSupport {
	public String exportExcel() {
		HttpServletResponse response = ServletActionContext.getResponse();

		response.setHeader("Content-Disposition", "attachment;filename=Excel1A.xls");

		// 在内存中创建一个Excel文件
		XSSFWorkbook workbook = new XSSFWorkbook();
		// 创建工作表，指定工作表名称
		XSSFSheet sheet = workbook.createSheet("SheetA");

		// 创建行，0表示第一行
		XSSFRow row = sheet.createRow(0);
		// 创建单元格，0表示第一个单元格
		row.createCell(0).setCellValue("编号");
		row.createCell(1).setCellValue("姓名");
		row.createCell(2).setCellValue("年龄");

		XSSFRow row1 = sheet.createRow(1);
		row1.createCell(0).setCellValue("1");
		row1.createCell(1).setCellValue("张三");
		row1.createCell(2).setCellValue("10");

		try {
			// 获取流发送给前台
			ServletOutputStream outputStream = response.getOutputStream();
			try {
				workbook.write(outputStream);
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return "exportExcelSuccess";
	}

}
