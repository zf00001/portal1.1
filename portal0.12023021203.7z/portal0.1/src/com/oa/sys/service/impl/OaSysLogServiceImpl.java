package com.oa.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oa.sys.dao.OaSysLogDao;
import com.oa.sys.model.OaSysLog;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Service
public class OaSysLogServiceImpl implements OaSysLogService {
	@Autowired
	private OaSysLogDao oaSysLogDao;

	public OaSysLogDao getOaSysLogDao() {
		return oaSysLogDao;
	}

	public void setOaSysLogDao(OaSysLogDao oaSysLogDao) {
		this.oaSysLogDao = oaSysLogDao;
	}

	@Override
	public PageUtil<OaSysLog> findByPage(Integer currPage, String optype, String opid) {
		PageUtil<OaSysLog> pageBean = new PageUtil<OaSysLog>();
		// 设置当前页数
		pageBean.setCurrPage(currPage);
		// 设置每页显示记录数
		int pageSize = 5;
		pageBean.setPageSize(pageSize);
		// 设置总记录数
		int totalCount = oaSysLogDao.findCount(optype, opid);
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		double tc = totalCount;
		Double num = Math.ceil(tc / pageSize);
		pageBean.setTotalPage(num.intValue());
		// 设置每页显示的数据
		int begin = (currPage - 1) * pageSize;
		List<OaSysLog> list = oaSysLogDao.findByPage(begin, pageSize, optype, opid);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(OaSysLog oaSysLog) {
		oaSysLogDao.save(oaSysLog);
	}

	@Override
	public OaSysLog findById(String lid) {
		return oaSysLogDao.findById(lid);
	}

}
