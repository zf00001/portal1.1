package com.oa.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oa.sys.dao.OaSysRoleDao;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.service.OaSysRoleService;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Service
public class OaSysRoleServiceImpl implements OaSysRoleService {
	@Autowired
	private OaSysRoleDao oaSysRoleDao;

	public OaSysRoleDao getOaSysRoleDao() {
		return oaSysRoleDao;
	}

	public void setOaSysRoleDao(OaSysRoleDao oaSysRoleDao) {
		this.oaSysRoleDao = oaSysRoleDao;
	}

	@Override
	public PageUtil<OaSysRole> findByPage(Integer currPage) {
		PageUtil<OaSysRole> pageBean = new PageUtil<OaSysRole>();
		// 设置当前页数
		pageBean.setCurrPage(currPage);
		// 设置每页显示记录数
		int pageSize = 5;
		pageBean.setPageSize(pageSize);
		// 设置总记录数
		int totalCount = oaSysRoleDao.findCount();
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		double tc = totalCount;
		Double num = Math.ceil(tc / pageSize);
		pageBean.setTotalPage(num.intValue());
		// 设置每页显示的数据
		int begin = (currPage - 1) * pageSize;
		List<OaSysRole> list = oaSysRoleDao.findByPage(begin, pageSize);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(OaSysRole oaSysRole) {
		oaSysRoleDao.save(oaSysRole);
	}

	@Override
	public OaSysRole findById(String rid) {
		return oaSysRoleDao.findById(rid);
	}

	@Override
	public void update(OaSysRole oaSysRole) {
		oaSysRoleDao.update(oaSysRole);
	}

	@Override
	public List<OaSysRole> findAll() {
		return oaSysRoleDao.findAll();
	}

}
