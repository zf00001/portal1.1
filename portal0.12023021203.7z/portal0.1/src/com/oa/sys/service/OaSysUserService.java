package com.oa.sys.service;

import com.oa.sys.model.OaSysUser;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysUserService {
	PageUtil<OaSysUser> findByPage(Integer currPage);

	void save(OaSysUser oaSysUser);

	OaSysUser findById(String uid);

	void update(OaSysUser oaSysUser);

	OaSysUser findByUsernameAndPassword(String username, String password);

	OaSysUser findByUsername(String username);

	OaSysUser findBySys();

	OaSysUser findByUsernameForUpdate(String uid, String username);

	void saveOnlineOaSysUser(String uid, String sessionid);

	void deleteOnlineOaSysUser(String uid);
}
