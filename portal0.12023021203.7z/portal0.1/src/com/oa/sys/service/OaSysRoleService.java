package com.oa.sys.service;

import java.util.List;

import com.oa.sys.model.OaSysRole;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月4日.
 */
public interface OaSysRoleService {
	PageUtil<OaSysRole> findByPage(Integer currPage);

	void save(OaSysRole oaSysRole);

	OaSysRole findById(String rid);

	void update(OaSysRole oaSysRole);

	List<OaSysRole> findAll();
}
