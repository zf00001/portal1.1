package com.oa.sys.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.oa.sys.dao.OaSysDepartmentDao;
import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.util.DataUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Repository
public class OaSysDepartmentDaoImpl extends HibernateDaoSupport implements OaSysDepartmentDao {

	@Override
	public int findCount() {
		String hql = "select count(*) from OaSysDepartment where isdel=" + DataUtil.adddata + " ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return Integer.parseInt(list.get(0).toString());
		} else {
			return 0;
		}
	}

	@Override
	public List<OaSysDepartment> findByPage(int begin, int pageSize) {
		DetachedCriteria criteria = DetachedCriteria.forClass(OaSysDepartment.class);
		;
		criteria.add(Restrictions.eq("isdel", DataUtil.adddata));
		criteria.addOrder(Order.desc("did"));

		List<OaSysDepartment> list = (List<OaSysDepartment>) this.getHibernateTemplate().findByCriteria(criteria, begin,
				pageSize);
		return list;
	}

	@Override
	public void save(OaSysDepartment oaSysDepartment) {
		this.getHibernateTemplate().save(oaSysDepartment);
	}

	@Override
	public OaSysDepartment findById(String did) {
		OaSysDepartment oaSysDepartment = this.getHibernateTemplate().get(OaSysDepartment.class, did);
		return oaSysDepartment;
	}

	@Override
	public void update(OaSysDepartment oaSysDepartment) {
		HibernateTemplate template = this.getHibernateTemplate();
		this.getHibernateTemplate().update(oaSysDepartment);
	}

	@Override
	public List<OaSysDepartment> findAll() {
		String hql = "from OaSysDepartment where isdel=" + DataUtil.adddata + " ";
		List<OaSysDepartment> list = (List<OaSysDepartment>) this.getHibernateTemplate().find(hql);
		return list;
	}
}
