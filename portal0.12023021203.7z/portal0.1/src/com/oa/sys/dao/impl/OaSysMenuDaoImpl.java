package com.oa.sys.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.oa.sys.dao.OaSysMenuDao;
import com.oa.sys.model.OaSysMenu;
import com.oa.sys.util.DataUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Repository
public class OaSysMenuDaoImpl extends HibernateDaoSupport implements OaSysMenuDao {

	@Override
	public int findCount() {
		String hql = "select count(*) from OaSysMenu where isdel=" + DataUtil.adddata + " ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return Integer.parseInt(list.get(0).toString());
		} else {
			return 0;
		}
	}

	@Override
	public List<OaSysMenu> findByPage(int begin, int pageSize) {
		DetachedCriteria criteria = DetachedCriteria.forClass(OaSysMenu.class);
		criteria.add(Restrictions.eq("isdel", DataUtil.adddata));
		criteria.addOrder(Order.desc("mid"));

		List<OaSysMenu> list = (List<OaSysMenu>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		return list;
	}

	@Override
	public void save(OaSysMenu oaSysMenu) {
		this.getHibernateTemplate().save(oaSysMenu);

	}

	@Override
	public OaSysMenu findById(String mid) {
		OaSysMenu oaSysMenu = this.getHibernateTemplate().get(OaSysMenu.class, mid);
		return oaSysMenu;
	}

	@Override
	public void update(OaSysMenu oaSysMenu) {
		HibernateTemplate template = this.getHibernateTemplate();
		this.getHibernateTemplate().update(oaSysMenu);
	}

}
