package com.oa.sys.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.oa.sys.dao.OaSysUserDao;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.util.DataUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Repository
public class OaSysUserDaoImpl extends HibernateDaoSupport implements OaSysUserDao {

	@Override
	public int findCount() {
		String hql = "select count(*) from OaSysUser where isdel=" + DataUtil.adddata + " and issys=" + DataUtil.guest
				+ " ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return Integer.parseInt(list.get(0).toString());
		} else {
			return 0;
		}
	}

	@Override
	public List<OaSysUser> findByPage(int begin, int pageSize) {
		DetachedCriteria criteria = DetachedCriteria.forClass(OaSysUser.class);
		criteria.add(Restrictions.eq("isdel", DataUtil.adddata));
		criteria.add(Restrictions.eq("issys", DataUtil.guest));
		criteria.addOrder(Order.desc("uid"));

		List<OaSysUser> list = (List<OaSysUser>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		return list;
	}

	@Override
	public void save(OaSysUser oaSysUser) {
		this.getHibernateTemplate().save(oaSysUser);
	}

	@Override
	public OaSysUser findById(String uid) {
		return this.getHibernateTemplate().get(OaSysUser.class, uid);
	}

	@Override
	public void update(OaSysUser oaSysUser) {
		this.getHibernateTemplate().update(oaSysUser);
	}

	@Override
	public OaSysUser findByUsernameAndPassword(String username, String password) {
		String hql = "from OaSysUser where username = ? and password= ? and isdel=" + DataUtil.adddata + " ";
		List<?> list = this.getHibernateTemplate().find(hql, username, password);
		if (list.size() > 0) {
			return (OaSysUser) list.get(0);
		} else {
			return null;
		}
	}

	@Override
	public OaSysUser findByUsername(String username) {
		String hql = "from OaSysUser where username = ? and isdel=" + DataUtil.adddata + " ";
		List<?> list = this.getHibernateTemplate().find(hql, username);
		if (list.size() > 0) {
			return (OaSysUser) list.get(0);
		} else {
			return null;
		}
	}

	@Override
	public OaSysUser findBySys() {
		String hql = "from OaSysUser where isdel=" + DataUtil.adddata + " and issys=" + DataUtil.admin + " ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return (OaSysUser) list.get(0);
		} else {
			return null;
		}
	}

	@Override
	public OaSysUser findByUsernameForUpdate(String uid, String username) {
		String hql = "from OaSysUser where username = ? and isdel=" + DataUtil.adddata + " and uid!= ? ";
		List<?> list = this.getHibernateTemplate().find(hql, username, uid);
		if (list.size() > 0) {
			return (OaSysUser) list.get(0);
		} else {
			return null;
		}
	}
}
